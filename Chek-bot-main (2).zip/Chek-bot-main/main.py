
import logging
import os
import json
from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from aiogram.dispatcher import FSMContext
from aiogram.dispatcher.filters.state import State, StatesGroup
from aiogram.utils import executor
from PIL import Image, ImageDraw, ImageFont
from datetime import datetime, timedelta
import re
import pytz

# Configuration
API_TOKEN = 'BOT_TOKEN'
VIP_FILE = 'vip_users.json'
STATS_FILE = 'user_stats.json'
ADMIN_IDS = [ADMIN_ID_YOZILADI]
MAX_DAILY_CHECKS = 5  # Maximum checks per day for regular users

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Initialize bot
bot = Bot(token=API_TOKEN)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)

# Timezone setup
UZ_TZ = pytz.timezone('Asia/Tashkent')

# States
class Form(StatesGroup):
    name = State()
    phone = State()
    amount = State()

# Decorator to check ongoing processes
def check_state(func):
    async def wrapper(message: types.Message, state: FSMContext):
        current_state = await state.get_state()
        if current_state is not None and not current_state.startswith('Form:'):
            await message.answer("⚠️ Sizda davom etayotgan jarayon bor. Iltimos, avval uni tugating yoki /cancel buyrug'i bilan bekor qiling.")
            return
        return await func(message, state)
    return wrapper

# Cancel command handler
@dp.message_handler(commands=['cancel'], state='*')
async def cmd_cancel(message: types.Message, state: FSMContext):
    current_state = await state.get_state()
    if current_state is None:
        await message.answer("❌ Hech qanday aktiv jarayon yo'q.")
        return
    
    await state.finish()
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add("✅ Chek yasash", "💎 VIP obuna")
    if message.from_user.id in ADMIN_IDS:
        keyboard.add("👑 Admin panel")
    
    await message.answer("❌ Jarayon bekor qilindi.", reply_markup=keyboard)

# Data handling functions
def load_vip_users():
    try:
        if not os.path.exists(VIP_FILE):
            with open(VIP_FILE, 'w', encoding='utf-8') as f:
                json.dump([], f, ensure_ascii=False)
        with open(VIP_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"VIP faylni o'qishda xato: {e}")
        return []

def save_vip_users(vip_users):
    try:
        with open(VIP_FILE, 'w', encoding='utf-8') as f:
            json.dump(vip_users, f, ensure_ascii=False)
    except Exception as e:
        logger.error(f"VIP faylga yozishda xato: {e}")

def load_stats():
    try:
        if not os.path.exists(STATS_FILE):
            return {
                'total_checks': 0,
                'today_checks': 0,
                'last_reset': datetime.now(UZ_TZ).strftime('%Y-%m-%d'),
                'users': {}
            }
        with open(STATS_FILE, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception as e:
        logger.error(f"Statistika faylni o'qishda xato: {e}")
        return {
            'total_checks': 0,
            'today_checks': 0,
            'last_reset': datetime.now(UZ_TZ).strftime('%Y-%m-%d'),
            'users': {}
        }

def save_stats(stats):
    try:
        with open(STATS_FILE, 'w', encoding='utf-8') as f:
            json.dump(stats, f, ensure_ascii=False)
    except Exception as e:
        logger.error(f"Statistika faylga yozishda xato: {e}")

def update_stats(user_id, username=None):
    stats = load_stats()
    now = datetime.now(UZ_TZ)
    
    # Reset daily stats if it's a new day
    last_reset = datetime.strptime(stats['last_reset'], '%Y-%m-%d').date()
    if now.date() > last_reset:
        stats['today_checks'] = 0
        stats['last_reset'] = now.strftime('%Y-%m-%d')
    
    stats['total_checks'] += 1
    stats['today_checks'] += 1
    
    user_id_str = str(user_id)
    if user_id_str not in stats['users']:
        stats['users'][user_id_str] = {
            'checks': 0,
            'first_check': now.strftime('%Y-%m-%d %H:%M:%S'),
            'username': username or ''
        }
    stats['users'][user_id_str]['checks'] += 1
    stats['users'][user_id_str]['last_check'] = now.strftime('%Y-%m-%d %H:%M:%S')
    if username and not stats['users'][user_id_str]['username']:
        stats['users'][user_id_str]['username'] = username
    
    save_stats(stats)
    return stats['users'][user_id_str]['checks']

def is_vip(user_id):
    vip_users = load_vip_users()
    return str(user_id) in map(str, vip_users)

def can_create_check(user_id):
    if is_vip(user_id):
        return True, None
    
    stats = load_stats()
    user_id_str = str(user_id)
    if user_id_str in stats['users']:
        today_checks = stats['users'][user_id_str].get('today_checks', 0)
        if today_checks >= MAX_DAILY_CHECKS:
            reset_time = datetime.strptime(stats['last_reset'], '%Y-%m-%d').date()
            tomorrow = (datetime.now(UZ_TZ) + timedelta(days=1)).date()
            remaining = (tomorrow - reset_time).days
            return False, f"⚠️ Sizning kunlik cheklar chegarangiz tugadi ({MAX_DAILY_CHECKS}/kun). Keyingi kun {remaining * 24} soatdan keyin."
    return True, None

# Start command handler
@dp.message_handler(commands=['start'])
async def cmd_start(message: types.Message):
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add("✅ Chek yasash", "💎 VIP obuna")
    if message.from_user.id in ADMIN_IDS:
        keyboard.add("👑 Admin panel")
    await message.answer("Kerakli bo'limni tanlang:", reply_markup=keyboard)

# Check creation handlers
@dp.message_handler(lambda m: m.text == "✅ Chek yasash")
@check_state
async def start_check(message: types.Message, state: FSMContext):
    can_create, error_msg = can_create_check(message.from_user.id)
    if not can_create:
        await message.answer(error_msg)
        return
    
    await Form.name.set()
    await message.answer("👤 Qabul qiluvchining ismini kiriting. Ismini kiritganda 1-to'liq ism va joy tashlab kattada familiyasining bosh harifi va nuqta:\nMasalan: Artyom K.")

@dp.message_handler(state=Form.name)
async def process_name(message: types.Message, state: FSMContext):
    if len(message.text) < 3:
        await message.answer("❌ Ism juda qisqa. Iltimos, to'liq ism kiriting.")
        return
    if not re.match(r"^[a-zA-Zа-яА-ЯёЁ']+ [A-ZА-ЯЁ]\.$", message.text):
        await message.answer("❌ Noto'g'ri format. Iltimos, quyidagi formatda kiriting:\nMasalan: Artyom K.")
        return
    
    await state.update_data(name=message.text)
    await Form.next()
    await message.answer("📞 Telefon raqamingizni kiriting:\nFormat: +998941234565")

@dp.message_handler(state=Form.phone)
async def process_phone(message: types.Message, state: FSMContext):
    phone = message.text
    if not re.match(r"^\+998\d{9}$", phone):
        await message.answer("❌ Noto'g'ri format. To'g'ri format: +998941234565")
        return
    
    await state.update_data(phone=phone)
    await Form.next()
    await message.answer("💰 Pul miqdorini kiriting (faqat raqamlarda):")

@dp.message_handler(state=Form.amount)
async def process_amount(message: types.Message, state: FSMContext):
    if not re.fullmatch(r"[0-9 ]+", message.text):
        await message.answer("❌ Faqat raqam yoki boshliq kiriting!")
        return
        
    await state.update_data(amount=message.text)
    data = await state.get_data()
    await state.finish()

    try:
        user_id = message.from_user.id
        checks_count = update_stats(user_id, message.from_user.username)
        
        image_path = generate_transaction_image(
            name=data['name'],
            phone=data['phone'],
            amount=data['amount'],
            is_vip=is_vip(user_id))
        
        caption = "✅ Tayyor!"
        if not is_vip(user_id):
            caption += f"\n\nSiz {checks_count}/{MAX_DAILY_CHECKS} chek yaratdingiz (kunlik chegarasi)"
        
        await message.answer_photo(types.InputFile(image_path), caption=caption)
        os.remove(image_path)
    except Exception as e:
        logger.error(f"Chek yaratishda xato: {e}", exc_info=True)
        await message.answer("❌ Chek yaratishda xato yuz berdi. Iltimos, qayta urinib ko'ring.")

# VIP menu handler
@dp.message_handler(lambda m: m.text == "💎 VIP obuna")
async def vip_menu(message: types.Message):
    if is_vip(message.from_user.id):
        text = "🎉 Siz allaqachon VIP obunachisiz!"
    else:
        text = (
            "💎 VIP obunachi bo'lish uchun quyidagi adminlardan biriga murojat qiling:\n"
            "1-admin: @V1RU5_admin\n"
           
            "VIP afzalliklari:\n"
            f"- Kunlik {MAX_DAILY_CHECKS} ta chek chegarasiz\n"
            "- Cheklarda 'SOXTA CHEK' yozuvi bo'lmaydi\n"
            "- Boshqa imtiyozlar"
        )
    await message.answer(text)

# Photo handler for payments
@dp.message_handler(content_types=types.ContentType.PHOTO)
async def handle_photo(message: types.Message):
    if message.caption and "to'lov" in message.caption.lower():
        for admin_id in ADMIN_IDS:
            try:
                await bot.send_photo(
                    admin_id, 
                    message.photo[-1].file_id, 
                    caption=f("📥 Yangi to'lov\nFrom: @{message.from_user.username or 'Noma'lum'} (ID: {message.from_user.id})"
                ))
            except Exception as e:
                logger.error(f"Adminga fotoni yuborishda xato: {e}")

# Admin panel handlers
@dp.message_handler(lambda m: m.text == "👑 Admin panel")
async def admin_panel(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        await message.answer("❌ Ruxsat etilmagan!")
        return
    
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.add("📊 Statistika", "📤 Xabar yuborish")
    keyboard.add("➕ VIP ga qo'shish", "➖ VIP dan chiqarish")
    keyboard.add("⬅️ Ortga")
    await message.answer("👑 Admin paneliga xush kelibsiz!", reply_markup=keyboard)

@dp.message_handler(lambda m: m.text == "📊 Statistika")
async def stats(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    
    stats = load_stats()
    now = datetime.now(UZ_TZ)
    
    active_users = sum(1 for user in stats['users'].values() if datetime.strptime(user['last_check'], '%Y-%m-%d %H:%M:%S').date() == now.date())
    
    response = (
        f"📊 Bot statistikasi:\n\n"
        f"• Jami cheklar: {stats['total_checks']}\n"
        f"• Bugungi cheklar: {stats['today_checks']}\n"
        f"• Ro'yxatdan o'tgan foydalanuvchilar: {len(stats['users'])}\n"
        f"• Faol foydalanuvchilar (bugun): {active_users}\n\n"
        f"⏳ So'ngi yangilanish: {now.strftime('%Y-%m-%d %H:%M:%S')}"
    )
    
    await message.answer(response)

@dp.message_handler(lambda m: m.text == "📤 Xabar yuborish")
async def broadcast_prompt(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    
    await message.answer("📩 Barcha foydalanuvchilarga yubormoqchi bo'lgan xabaringizni yuboring:", reply_markup=types.ForceReply())

@dp.message_handler(lambda m: m.reply_to_message and m.reply_to_message.text == "📩 Barcha foydalanuvchilarga yubormoqchi bo'lgan xabaringizni yuboring:")
async def broadcast_message(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    
    stats = load_stats()
    users = stats['users'].keys()
    total = len(users)
    success = 0
    failed = 0
    
    progress_msg = await message.answer(f"📤 Xabar {total} ta foydalanuvchiga yuborilmoqda...")
    
    for user_id in users:
        try:
            await bot.send_message(user_id, message.text)
            success += 1
        except Exception as e:
            logger.error(f"Foydalanuvchiga xabar yuborishda xato (ID: {user_id}): {e}")
            failed += 1
    
    await progress_msg.delete()
    await message.answer(
        f"✅ Xabar yuborish yakunlandi!\n\n"
        f"• Muvaffaqiyatli: {success}\n"
        f"• Muvaffaqiyatsiz: {failed}\n"
        f"• Jami: {total}"
    )

@dp.message_handler(lambda m: m.text == "➕ VIP ga qo'shish")
async def add_vip_prompt(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    
    await message.answer("🆔 VIPga qo'shmoqchi bo'lgan foydalanuvchi ID sini kiriting:", reply_markup=types.ForceReply())

@dp.message_handler(lambda m: m.reply_to_message and m.reply_to_message.text == "🆔 VIPga qo'shmoqchi bo'lgan foydalanuvchi ID sini kiriting:")
async def add_vip_id(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    
    vip_users = load_vip_users()
    if message.text not in vip_users:
        vip_users.append(message.text)
        save_vip_users(vip_users)
        await message.answer(f"✅ {message.text} VIP ga qo'shildi.")
    else:
        await message.answer("⚠️ Bu foydalanuvchi allaqachon VIP.")

@dp.message_handler(lambda m: m.text == "➖ VIP dan chiqarish")
async def remove_vip_prompt(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    
    vip_users = load_vip_users()
    if not vip_users:
        await message.answer("📭 VIP ro'yxati bo'sh.")
        return
    
    text = "🧾 VIP foydalanuvchilar:\n"
    for uid in vip_users:
        text += f"- {uid}\n"
    await message.answer(text + "\n❌ O'chirmoqchi bo'lgan ID ni yuboring:", reply_markup=types.ForceReply())

@dp.message_handler(lambda m: m.reply_to_message and "O'chirmoqchi bo'lgan ID ni yuboring:" in m.reply_to_message.text)
async def remove_vip_id(message: types.Message):
    if message.from_user.id not in ADMIN_IDS:
        return
    
    vip_users = load_vip_users()
    if message.text in vip_users:
        vip_users.remove(message.text)
        save_vip_users(vip_users)
        await message.answer(f"❌ {message.text} VIP ro'yxatidan o'chirildi.")
    else:
        await message.answer("❌ Bunday ID topilmadi.")

# Back to main menu
@dp.message_handler(lambda m: m.text == "⬅️ Ortga")
async def back_to_main(message: types.Message):
    await cmd_start(message)

# Utility functions
def mask_phone(phone):
    return f"+998 {phone[4:6]} *** ** {phone[-2:]}" if len(phone) == 13 else phone

def generate_transaction_image(name, phone, amount, is_vip=False):
    try:
        template = 'template.jpg'
        font_regular = 'fonts/Roboto-Regular.ttf'
        font_bold = 'fonts/Roboto-Bold.ttf'
        output_path = f"output_{datetime.now(UZ_TZ).strftime('%Y%m%d_%H%M%S')}.jpg"

        img = Image.open(template).convert("RGB")
        draw = ImageDraw.Draw(img)

        now = datetime.now(UZ_TZ)
        offset_time = now - timedelta(minutes=1, seconds=35)

        font_name = ImageFont.truetype(font_bold, 55)
        font_phone = ImageFont.truetype(font_regular, 35)
        font_datetime = ImageFont.truetype(font_regular, 37)
        font_amount = ImageFont.truetype(font_bold, 60)
        font_som = ImageFont.truetype(font_regular, 38)
        font_fake = ImageFont.truetype(font_bold, 120)

        # Main texts
        draw.text((300, 116), name, font=font_name, fill="white")
        if len(name) >= 2:
            initials = name[0].upper() + name[-2].upper()
            draw.text((177, 132), initials, font=font_name, fill="white")

        draw.text((300, 185), mask_phone(phone), font=font_phone, fill="white")
        
        # Uzbek month names
        uzbek_months = {
            1: "yanvar", 2: "fevral", 3: "mart", 4: "aprel", 
            5: "may", 6: "iyun", 7: "iyul", 8: "avgust", 
            9: "sentabr", 10: "oktabr", 11: "noyabr", 12: "dekabr"
        }
        month_name = uzbek_months.get(now.month, now.strftime("%B").lower())
        draw.text((500, 1540), f"{now.day} {month_name}", font=font_datetime, fill="gray")
        
        draw.text((644, 1688), offset_time.strftime("%H:%M"), font=font_datetime, fill="gray")
        draw.text((79, 18), now.strftime("%H:%M"), font=font_datetime, fill="white")

        draw.text((398, 1760), amount, font=font_amount, fill="white")
        text_width = draw.textbbox((0, 0), amount, font=font_amount)[2]
        draw.text((398 + text_width + 10, 1780), "so'm", font=font_som, fill="white")

        if not is_vip:
            draw.text((100, 1830), "SOXTA CHEK", font=font_fake, fill="red")

        img.save(output_path)
        return output_path
    except Exception as e:
        logger.error(f"Rasm yaratishda xato: {e}")
        raise

# Main execution
if __name__ == '__main__':
    try:
        logger.info("Bot ishga tushmoqda...")
        executor.start_polling(dp, skip_updates=True)
    except Exception as e:
        logger.critical(f"Bot ishga tushirishda kritik xato: {e}", exc_info=True)
    finally:
        logger.info("Bot to'xtatildi")
